﻿// TODO add this to class diagram v2
namespace Types
{
	public struct UserTypes
	{
		public const string STUDENT = "student";
		public const string PROFESSOR = "professor";
		public const string ADMIN = "admin";
	}

	public struct FormFactoryTypes
	{
		public const string USER_FORM = "user_form";
	}
}